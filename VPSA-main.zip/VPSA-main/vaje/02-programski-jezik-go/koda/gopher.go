/*
Program gopher izriše podobo ASCII ravninske mošnjičarke (angl. Pocket Gopher),
maskote programskega jezika go.
*/
package main

import "fmt"

func main() {
	//Prikaži ASCII Art
	fmt.Println("\nRavninska mošnjičarka (angl. Pocket gopher)\n")
	fmt.Println("       `.-::::::-.`")
	fmt.Println("   .:-::::::::::::::-:.")
	fmt.Println("   `_:::    ::    :::_`")
	fmt.Println("    .:( ^   :: ^   ):.")
	fmt.Println("    `:::   (..)   :::.")
	fmt.Println("    `:::::::UU:::::::`")
	fmt.Println("    .::::::::::::::::.")
	fmt.Println("    O::::::::::::::::O")
	fmt.Println("    -::::::::::::::::-")
	fmt.Println("    `::::::::::::::::`")
	fmt.Println("     .::::::::::::::.")
	fmt.Println("       oO:::::::Oo")

}
