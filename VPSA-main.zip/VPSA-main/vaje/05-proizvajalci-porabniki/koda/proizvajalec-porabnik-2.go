/*
Primer proizvajalec porabnik
Ustvarimo proizvajalce in porabnike, na koncu preverimo, kaj se je zgodilo z zahtevami.
Glavna nit pošlje signal za zaustavitev. Težava, ne vemo kdaj se gorutine zares ustavijo.
*/
package main

import (
	"fmt"
	"time"
)

type producer struct {
	id      int
	counter int
}

type consumer struct {
	id      int
	counter int
}

func (p *producer) start(id int, interval time.Duration, data chan<- int, quit <-chan struct{}) {
	p.id = id
	for {
		select {
		case <-quit:
			return
		default:
			p.counter++
			data <- p.counter
		}
		time.Sleep(interval)
	}
}

func (c *consumer) start(id int, interval time.Duration, data <-chan int, quit <-chan struct{}) {
	c.id = id
	for {
		select {
		case <-data:
			c.counter++
		case <-quit:
			return
		}
		time.Sleep(interval)
	}
}

func checkWork(ps []producer, cs []consumer) {
	total := 0
	for i, p := range ps {
		total += p.counter
		fmt.Println("P", i, p.counter)
	}

	for i, c := range cs {
		total -= c.counter
		fmt.Println("C", i, c.counter)
	}
	fmt.Println("TOTAL:", total)
}
func main() {
	data := make(chan int, 100)
	quit := make(chan struct{})
	nProducers := 10
	nConsumers := 10

	producers := make([]producer, nProducers)
	consumers := make([]consumer, nConsumers)
	intervalProducers := 0 * time.Millisecond
	intervalConsumers := 0 * time.Millisecond

	for i := range producers {
		go producers[i].start(i, intervalProducers, data, quit)
	}

	for i := range consumers {
		go consumers[i].start(i, intervalConsumers, data, quit)
	}

	time.Sleep(2 * time.Second)
	close(quit)
	checkWork(producers, consumers)

}
